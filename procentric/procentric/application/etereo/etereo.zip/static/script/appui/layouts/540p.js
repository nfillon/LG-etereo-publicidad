define(
  'homeapp/appui/layouts/540p',
  {
    classes: [
      "layout540p"
    ],
    css: [
      "layouts/540p.css"
    ],
    requiredScreenSize: {
      width: 960,
      height: 540
    }
  }
);
